#!/usr/bin/env bash

source rlec_install_utils_tmpdir/install_functions

# a custom installation script to be used when installing with non-default paths or users

function custom_install()
{
    set -e
    test -z "$scriptlet_dir" && custom_installer_abort "redislabs_env_config file is not sourced"

    CUSTOM_INSTALL=true

    [ "$DISTRO_TYPE" != "redhat" ] && custom_installer_abort "Currently only RHEL distibutions supported by custom installer"

    local package=$1
    test -z "$package" && custom_installer_abort "No package supplied to custom installer"
    test -f "$package" || custom_installer_abort "Specified package file $package does not exist"
    package=$(_realpath $package)

    print progress "Installing via custom installer"
    move_to_staging_folder
    install_dependencies "$package"
    is_redislabs_installed && load_scriptlets "old"
    extract_package_scriptlets "$package"
    load_scriptlets "new"
    pre_trans_logic
    pre_install_logic
    extract_package "$package"
    place_pkg_files
    post_install_logic
    pre_uninstall_logic
    ## uninstall old
    post_uninstall_logic
    post_trans_logic
    mark_installation_done
    custom_installer_cleanup
}

function move_to_staging_folder()
{
    ORIG_DIR=$(_realpath $(pwd))
    STAGING_DIR=$(mktemp -d "custom_installer_staging_XXXXXX")
    STAGING_DIR=$(_realpath $STAGING_DIR)

    pushd $STAGING_DIR > /dev/null
}

function install_dependencies()
{
    local package=$1
    test -z "$package" && custom_installer_abort "No package specified"

    print progress "Installing dependencies for package $(basename $package)"

    if [ "$DISTRO_TYPE" == "redhat" ]; then
        local dep_pkgs=$(yum deplist $package | awk '/provider:/ {print $2}' | sort -u)
        execute yum -y install $dep_pkgs
    else
        custom_installer_abort "dependent packages for debian not yet implemented"
    fi
}

function custom_installer_cleanup()
{
    print progress "cleaning up custom installer files"
    test -n "$ORIG_DIR" && cd $ORIG_DIR
    if test -d "$STAGING_DIR"; then
        rm -rf $STAGING_DIR
    else
        print progress "No staging dir is defined."
    fi
    set +e
    #trap - ERR
}

function mark_installation_done()
{
    echo "$INSTALLATION_VERSION" > $CUSTOM_INSTALL_VERSION_FILE
    add_to_manifest $CUSTOM_INSTALL_VERSION_FILE
}

function extract_package()
{
    local package=$1
    test -z "$package" && custom_installer_abort "No package specified"

    # TODO handle unknown distro types and add an override flag
    if [ "$DISTRO_TYPE" == "redhat" ]; then
        extract_rpm $package
    else
        extract_deb $package
    fi
}

function extract_deb()
{
    local pkg=$1
    test -z "$pkg" && custom_installer_abort "Cannot extract deb package. no package has been specified"

    local dpkg_bin="/usr/bin/dpkg"
    test -x $dpkg_bin || custom_installer_abort "Cannot extract deb package contents - binary $dpkg_bin cannot be run"

    print progress "Extracting $(basename $pkg) into temporary staging folder"

    $dpkg_bin -x $pkg .
}

function get_binary()
{
    local bin_name=$1
    test -z "$bin_name" && custom_installer_abort "no binary name given to get_binary"

    local bin=$(which $bin_name 2>/dev/null)
    test -z "$bin" && custom_installer_abort "No binary found in path for $bin_name"

    test -x "$bin" || custom_installer_abort "$bin_name binary $bin cannot be executed"

    echo -n "$bin"
}

function extract_rpm()
{
    local pkg=$1
    test -z "$pkg" && custom_installer_abort "Cannot extract rpm. no package has been specified"

    local cpio_bin=$(get_binary cpio)
    local rpm2cpio_bin=$(get_binary rpm2cpio)

    print progress "Extracting $(basename $pkg) into temporary staging folder"

    $rpm2cpio_bin $pkg | $cpio_bin -id 2>/dev/null
}

function place_package_dir()
{
    local src_dir=$1
    local tgt_dir=$2
    local backup_existing=$3
    local add_self_to_manifest=$4

    pushd "$src_dir" > /dev/null

    if [ "$add_self_to_manifest" = true ]; then
        add_to_manifest "$tgt_dir"
    fi

    # Changing IFS is necessary to support filenames with whitespaces. This version will still fail on filenames
    # that contain newlines. Hopefully we won't have _those_ in our package in the foreseeable future.
    IFS=$'\n'
    for nm in $(find . -printf '%P\n'); do
        tgt="${tgt_dir}/${nm}"

        if [ -d "$nm" ]; then
            if [ ! -d "$tgt" ]; then
                mkdir -p "$tgt" || custom_installer_abort "Failed to create directory $tgt"
                add_to_manifest "$tgt"  # we only list directories we created ourselves in the manifest
            fi
        else
            if "$backup_existing" && [ -e "$tgt" ]; then
                print info "Backing up previously installed ${tgt} as ${tgt}.bak"
                mv "$tgt" "${tgt}.bak"
            fi
            mv "$nm" "$tgt"
            add_to_manifest "$tgt"
        fi
    done
    unset IFS

    chmods_all_the_way_up a+x $tgt_dir

    popd > /dev/null
    rm -r "$src_dir"/* "$src_dir" 2> /dev/null || true
}

function fix_files_ownership()
{
    IFS=$'\n'
    for f in $(get_manifest); do
        if test -d $f; then
            chown -R ${osuser}:${osgroup} $f
        elif test -f $f; then
            chown ${osuser}:${osgroup} $f
        elif test -L $f; then
            : # NOOP. Links are legal manifest entities, but permissions are set for the link target
        else
            custom_installer_abort "cannot set ownership for invalid file $f found in manifest"
        fi
    done
    unset IFS

    # all files are set to the configured user except for a few which we'll set to root
    # TODO this duplicates definitions from the spec file. how to remove this dependency?
    local files_owned_by_root
    if [ "$DISTRO_TYPE" == "redhat" ]; then
        files_owned_by_root="/usr/share/selinux/mls/redislabs.pp /usr/share/selinux/targeted/redislabs.pp"
    else
        files_owned_by_root=""
    fi
    for f in $files_owned_by_root; do
        chown root:root $f
    done
}

function place_pkg_files()
{
    create_manifest
    place_package_dir "opt/redislabs" "${installdir}" false true
    place_package_dir "var/opt/redislabs" "${vardir}" false true
    place_package_dir "etc/opt/redislabs" "${confdir}" false true
    place_package_dir "." "/" true false
    finalize_manifest
    fix_files_ownership
}

function extract_package_scriptlets()
{
    local package=$1
    test -z "$package" && custom_installer_abort "No package specified"

    if [ "$DISTRO_TYPE" == "redhat" ]; then
        extract_rpm_scriptlets $package
    else
        extract_deb_scriptlets $package
    fi
}

function extract_rpm_scriptlets()
{
    # this function extracts all scriptlets as individual functions into a single file to allow sourcing
    local pkg=$1
    test -z "$pkg" && custom_installer_abort "Cannot extract rpm scriptlets. no package has been specified"

    mkdir -p ${scriptlet_dir}
    output_file="${scriptlet_dir}/scriptlets.sh"
    echo "# file was auto-generated by [$(basename "$0")] on [$(date)] based on [$(rpm -qp ${pkg})]" > "$output_file"

    first_line=true
    while IFS= read -r line
    do
        if [[ "$line" =~ " scriptlet (using /bin/sh):" ]]; then

            if ! ${first_line}; then
                echo -e "}\n" >> "$output_file"
            fi
            echo "function scriptlet_${line%% *}() {" >> "$output_file"
            first_line=false

        else
            echo -e "\t${line}" >> "$output_file"
        fi
    done <<< "$(rpm -qp --scripts ${pkg})"
    echo -e "}\n" >> "$output_file"
}

function extract_deb_scriptlets()
{
    custom_installer_abort "scriptlet extraction currently not implemented for debian"
}

function select_action()
{
    is_redislabs_installed && echo upgrade || echo install
}

function pre_install_logic()
{
    run_scriptlet $(select_action) preinstall new
}

function post_install_logic()
{
    print progress "Performing post installation logic"

    if [ "$DISTRO_TYPE" == "debian" ]; then
        post_install_debian_logic
    else
        post_install_redhat_logic
    fi
}

function post_install_debian_logic()
{
    custom_installer_abort "Debian is not implemented yet"
}

function post_install_redhat_logic()
{
    run_scriptlet $(select_action) postinstall new
}

function pre_uninstall_logic()
{
    print progress "Performing pre uninstallation logic"

    if [ "$DISTRO_TYPE" == "debian" ]; then
        pre_uninstall_debian_logic
    else
        pre_uninstall_redhat_logic
    fi
}

function pre_uninstall_debian_logic()
{
    custom_installer_abort "Debian is not implemented yet"
}

function pre_uninstall_redhat_logic()
{
    local action=$(select_action)
    if [ "$action" != "install" ]; then
        run_scriptlet "$action" preuninstall old
    fi
}

function post_uninstall_logic()
{
    print progress "Performing post uninstallation logic"

    if [ "$DISTRO_TYPE" == "debian" ]; then
        post_uninstall_debian_logic
    else
        post_uninstall_redhat_logic
    fi
}

function post_uninstall_debian_logic()
{
    custom_installer_abort "Debian is not implemented yet"
}

function post_uninstall_redhat_logic()
{
    local action=$(select_action)
    if [ "$action" != "install" ]; then
        run_scriptlet "$action" postuninstall old
    fi
}

function pre_trans_logic()
{
    run_scriptlet $(select_action) pretrans new
}

function post_trans_logic()
{
    if [ "$DISTRO_TYPE" == "debian" ]; then
        :
    else
        print progress "Performing post transaction logic"
        run_scriptlet $(select_action) posttrans new
    fi
}

function create_manifest()
{
    rm -f $CUSTOM_INSTALL_MANIFEST_PATH
    mkdir -p $(dirname $CUSTOM_INSTALL_MANIFEST_PATH)
    touch $CUSTOM_INSTALL_MANIFEST_PATH
}

function add_to_manifest()
{
    local path=$1
    test -z "$path" && custom_installer_abort "No filename specified for manifest"

    echo "$path" >> $CUSTOM_INSTALL_MANIFEST_PATH
}

function finalize_manifest()
{
    add_to_manifest $CUSTOM_INSTALL_MANIFEST_PATH
}

function get_manifest()
{
    echo "$(<$CUSTOM_INSTALL_MANIFEST_PATH)"
}
