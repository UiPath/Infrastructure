import sys
import time
from datetime import datetime
from cnm import cnm_config
from cnm import CCS
from typing import Tuple  # noqa: F401


def usage():
    # type: () -> None
    print('usage: leash.py on|off')
    sys.exit(99)


LEASH_CONFIG = {
    'general:node_max_update_time': 60,
    'general:unstable_time_for_master_selection': 90
}

RETRY_COUNT = 8
TIMEOUT = 20
SLEEP_AFTER_NO_ANSWER = 5


def reconf_node(ccs, node_obj):
    # type: (CCS.Context, CCS.Node) -> Tuple[bool, str]
    opid_list = []
    status_listen = CCS.AdhocOpStatusListen(ccs)
    for _ in range(RETRY_COUNT):
        curr_timeout = float(TIMEOUT)
        opid_list.append(node_obj.invoke_adhoc_op(node_obj.uid(), 'watchdog_reconf'))
        start_time = time.time()
        if node_obj.uid() == cnm_config.get_current_node_uid():
            # If we are on the current node so the ccs might not be up and
            # that's why message might not get returned, so we can ignore
            # waiting for answer, as per #14938
            return True, 'done'
        while curr_timeout > 0:
            try:
                full_status = status_listen.get_status(curr_timeout)
            except AttributeError:
                # This fix is here as a reply to ticket #13969, as pyredis
                # fails to read the pubsubs some times
                return False, 'Error: Could not receive messages sent from {}'.format(node_obj)
            if full_status is None:
                break
            else:
                status_id, status = full_status
                curr_timeout = TIMEOUT - (time.time() - start_time)
                if status_id not in opid_list:
                    continue
                if status in ['error', 'done']:
                    return True, status
        time.sleep(SLEEP_AFTER_NO_ANSWER)
    return False, 'Error: %s did not reply' % node_obj


def reconf(ccs):
    # type: (CCS.Context) -> None
    for node_obj in ccs.get_node_list(ccs.node_list()).values():
        sys.stdout.write('- configuring %s ... ' % node_obj)
        sys.stdout.flush()
        reached, message = reconf_node(ccs, node_obj)
        print(message)
        if not reached:
            sys.stderr.write(("[%s] WARNING - Couldn't reset timeout "
                              "configuration on %s following node:%s upgrade."
                              " Please contact technical support\n") %
                             (datetime.now(), node_obj,
                              cnm_config.get_current_node_uid()))


def leash_on():
    # type: () -> None
    try:
        ccs = CCS.Context(wait_for_bootstrap=False)
    except CCS.NoCluster as e:
        print(str(e))
        sys.exit(1)

    if ccs.rc.exists('__cluster_wd_config_backup'):
        print('Watchdog backup configuration already exists!')
        print('Either leash off or use "DEL __cluster_wd_config_backup".')
        sys.exit(1)

    print('Backup up and updating watchdog configuration...')
    old_config = ccs.rc.hgetall('cluster_wd_config')
    if not old_config:
        old_config = {'__empty__': 0}
        print('No custom watchdog configuration found')
    ccs.rc.hmset('__cluster_wd_config_backup', old_config)
    ccs.rc.hmset('cluster_wd_config', LEASH_CONFIG)
    reconf(ccs)


def leash_off():
    # type: () -> None
    try:
        ccs = CCS.Context(wait_for_bootstrap=False)
    except CCS.NoCluster as e:
        print(str(e))
        sys.exit(1)

    if not ccs.rc.exists('__cluster_wd_config_backup'):
        print('Watchdog backup not found, is leash on?')
        sys.exit(1)

    print('Restoring backed up watchdog configuration')
    if ccs.rc.hgetall('__cluster_wd_config_backup').keys() == ['__empty__']:
        print('No custom configuration')
        ccs.rc.delete('__cluster_wd_config_backup')
        ccs.rc.delete('cluster_wd_config')
    else:
        ccs.rc.rename('__cluster_wd_config_backup', 'cluster_wd_config')
    reconf(ccs)


def main():
    # type: () -> None
    if len(sys.argv) != 2:
        usage()

    if sys.argv[1] == 'on':
        leash_on()
    elif sys.argv[1] == 'off':
        leash_off()
    else:
        usage()


if __name__ == '__main__':
    main()
