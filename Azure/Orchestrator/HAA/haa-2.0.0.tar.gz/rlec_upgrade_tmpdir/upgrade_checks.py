import sys
import argparse
import logging
from typing import List, Dict, Tuple  # noqa: F401

try:
    from cnm import CCS
    from cnm import ResourceManagement
    from cnm.restclient import RESTClient
    from cnm.cli.rladmin import ClusterStatus
except ImportError:
    # older version where cnm was not a package
    try:
        import CCS
        import ResourceManagement
        from restclient import RESTClient
        from cli.rladmin import ClusterStatus
    except ImportError:
        # older version where rladmin wasn't under cli.
        from rladmin import ClusterStatus


class PreUpgradeChecker:
    """
    A class that performs checks about cluster state to see if upgrade is possible.
    The function run_checks() is called from install.sh before upgrade is performed.
    Returns exit code that are synchronized with exit codes in install.sh.
    """

    ERROR_UNABLE_TO_READ_ERROR_CODES_FILE = 7

    def __init__(self):
        # type: () -> None
        self.error_codes = dict()  # type: Dict[str, int]
        self.init_error_codes_dict()
        try:
            self.ccs = CCS.Context(wait_for_bootstrap=False)
        except (CCS.NoCluster, CCS.ConfigError):
            sys.exit(self.error_codes['ERROR_FAILED_CONNECTING_TO_CCS'])
        self.nodes = self.ccs.get_node_list(self.ccs.node_list()).values()

    def init_error_codes_dict(self):
        # type: () -> None
        # Read error codes from upgrade_checks_error_codes.sh. If it doesn't exist it will crash install.sh too,
        # so exit properly when not being able to read it
        try:
            with open('rlec_upgrade_tmpdir/upgrade_checks_error_codes.sh') as f:
                for line in f:
                    [error_name, error_code] = line.split('=')
                    self.error_codes[error_name] = int(error_code)
        except IOError:
            sys.exit(self.ERROR_UNABLE_TO_READ_ERROR_CODES_FILE)

    def upgrade_attempt(self):
        # type: () -> None
        """
        Mark that upgrade was attempted on node in audit log
        """
        self.ccs.get_my_node().add_event(logging.INFO, 'upgrade_attempt')

    def check_enough_nodes_for_quorum(self, nodes_status):
        # type: (Dict[str, Tuple[str, int]]) -> None
        """
        Check that we have enough nodes for quorum: if all nodes are active, we can upgrade. Else, check if we have more
        than total_nodes_num/2 + 1 active nodes (without errors) so if some node goes down during upgrade, we will still
        have quorum.
        Exits with ERROR_NOT_ENOUGH_NODES_FOR_QUORUM upon error
        """
        active_nodes = 0
        total_nodes_num = len(self.nodes)
        for node_status in nodes_status.values():
            if 'OK' in node_status[0]:
                active_nodes += 1

        # for topologies with less than 3 nodes
        if active_nodes == total_nodes_num:
            return

        if active_nodes - 1 < total_nodes_num / 2 + 1:
            print("Not enough active nodes for quorum. There are only {} active nodes out of {} total nodes.".format(
                active_nodes, total_nodes_num))
            sys.exit(self.error_codes['ERROR_NOT_ENOUGH_NODES_FOR_QUORUM'])

    def check_enough_nodes_for_quorum_rackaware(self, nodes_status):
        # type: (Dict[str, Tuple[str, int]]) -> None
        """
        In a rackaware cluster, check that there is an active node with each rack_id
        Exists with ERROR_RACKAWARE_NOT_ALL_RACKS_HAVE_ACTIVE_NODE upon error
        """
        racks_with_active_nodes = set(node.rack_id(canonical=True) for node in self.nodes
                                      if 'OK' in nodes_status[node.node_uid()][0])
        racks = set([node.rack_id(canonical=True) for node in self.nodes])
        racks_without_active_node = racks - racks_with_active_nodes
        if len(racks_without_active_node) != 0:
            print("There isn't any active node with rack_ids {}.".format(list(racks_without_active_node)))
            sys.exit(self.error_codes['ERROR_RACKAWARE_NOT_ALL_RACKS_HAVE_ACTIVE_NODE'])

    def quorum_checks(self):
        # type: () -> None
        """
        Run all quorum checks in the class
        """
        nodes_status = ClusterStatus(self.ccs).nodes_status()
        self.check_enough_nodes_for_quorum(nodes_status)
        if ResourceManagement.Policy(self.ccs).rack_aware:
            self.check_enough_nodes_for_quorum_rackaware(nodes_status)

    def check_legacy_databases(self):
        # type: () -> None
        """
        Verify that there are no legacy (i.e., listener-based) databases.
        Those are no longer supported.
        """

        def is_legacy(bdb):
            # type: (CCS.BDB) -> bool
            return bool(bdb.get_attr('listener_list'))

        if any(is_legacy(bdb) for bdb in self.ccs.get_bdb_map().values()):
            sys.exit(self.error_codes['ERROR_LEGACY_DATABASES_EXIST'])

    def check_master_version(self, node_uid):
        # type: (str) -> None
        """
        Checks whether the master node's CNM version is different than the version
        of the node with the supplied UID
        :param node_uid: UID of the node of which version is going to be compared
        to the master node's
        """
        cluster_status = ClusterStatus(self.ccs)
        node_version = cluster_status.nodes[node_uid].cnm_version()
        master_node = cluster_status.master_node
        master_node_uid = master_node.uid()
        master_version = master_node.cnm_version()
        if master_node_uid != node_uid and master_version == node_version:
            sys.exit(self.error_codes['ERROR_MASTER_NOT_UPGRADED'])

    def check_cluster_nodes_versions(self, upgrade_node_new_version):
        # type: (str) -> None
        """
        Checks whether the node new version is the same or differ by one comparing the others nodes version.
        :param upgrade_node_new_version: the new version of the node which is going to be compared
        to the other cluster node's versions
        """

        version_set = {upgrade_node_new_version}

        cluster_status = ClusterStatus(self.ccs)

        for node_uid in cluster_status.nodes:
            node_version = cluster_status.nodes[node_uid].cnm_version()
            version_set.add(node_version)

        if len(version_set) > 2:
            sys.exit(self.error_codes['ERROR_CLUSTER_NODES_VERSIONS'])

    def check_certificates_in_ccs_and_disk_match(self, certificates_dir):
        # type: (str) -> None
        """
        If certificates are saved in ccs, check that the api,cm,proxy certs in ccs and disk are matching. Print message
        about all mismatching certificates and if one or more certificates mismatch return proper exit code.
        :param certificates_dir: conf_dir, the path to the directory where certificates are saved
        """
        certs_name_to_check = {'cm': 'Management UI', 'api': 'REST API', 'proxy': 'Database endpoint'}
        try:
            certificates_from_ccs = self.ccs.get_cluster().certificates()
        except AttributeError:
            # indicates version older than 5.0.1, where certificates weren't saved in ccs, so no need to check for match
            print("Certificates are not saved in ccs in this version")
            return

        was_certificate_mismatch = False
        for cert_type in certs_name_to_check.keys():
            cert_file = '{}/{}_cert.pem'.format(certificates_dir, cert_type)
            with open(cert_file, 'r') as f:
                cert_from_disk = f.read()
                if cert_from_disk != certificates_from_ccs['{}_cert'.format(cert_type)]:
                    print('{} SSL/TLS certificate on this node was not updated with the REST API.'.format(
                        certs_name_to_check.get(cert_type)))
                    was_certificate_mismatch = True

        if was_certificate_mismatch:
            sys.exit(self.error_codes['ERROR_CERT_ON_DISK_AND_CCS_MISMATCH'])

    def check_sm_availability(self):
        # type: () -> None
        for bdb in self.ccs.get_bdb_map().values():
            if bdb.cnm_exec_sm() and bdb.cnm_exec_state() != 'done' and bdb.cnm_exec_state() != 'error':
                sys.exit(self.error_codes['ERROR_SM_IS_BUSY'])

    def check_cluster_enables_changes(self):
        # type: () -> None
        try:
            if self.ccs.get_cluster().block_cluster_changes():
                sys.exit(self.error_codes['ERROR_CLUSTER_BLOCKS_CHANGES'])
        except AttributeError:
            # the old version doesn't have the block_cluster_changes feature yet
            pass

    def check_versions_match(self, supported_versions):
        # type: (List[str]) -> None
        """
        Verifying all shards are running a supported redis version
        :param supported_versions: the supported versions
        """
        for bdb in self.ccs.get_bdb_map().values():
            if bdb.redis_version() not in supported_versions:
                sys.exit(self.error_codes['ERROR_BDB_VERSION_NOT_SUPPORTED'])

    def shards_syncing(self):
        # type: () -> str
        return_value = ''
        try:
            client = RESTClient(ccs=self.ccs)
            response = client.get('/shards?extra_info_keys=master_link_status')
        except IOError:
            sys.exit(self.error_codes['ERROR_FAILED_CONNECTING_TO_REST_API'])

        if response.status_code != 200:
            sys.exit(self.error_codes['ERROR_FAILED_CONNECTING_TO_REST_API'])

        for shard_info in response.json():
            if 'master_link_status' in shard_info['redis_info'] and \
                    shard_info['redis_info']['master_link_status'] != 'up':
                return_value += ('{}:{}\n'.format(shard_info['uid'], shard_info['bdb_uid']))
        return return_value


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--upgrade-attempt', action='store_true', help='Mark node upgrade attempt in audit log')
    parser.add_argument('--quorum', action='store_true', help='Check that cluster has quorum for upgrade')
    parser.add_argument('--check-legacy-databases', action='store_true',
                        help='Verify that there are no legacy databases')
    parser.add_argument('--check-master-version', action='store_true',
                        help='Verify that the master node has already been upgraded')
    parser.add_argument('--node-uid', help='In case needed, node UID for the test')
    parser.add_argument('--node-new-version', help='Check the cluster nodes versions vs the upgraded node version')
    parser.add_argument('--check-certs-match', help='Check that api/proxy/cm certificates match in ccs and disk, '
                                                    'using the given path to certificates directory')
    parser.add_argument('--check-sm-availability', action='store_true',
                        help='Verify that the state machine is not busy')
    parser.add_argument('--shards-syncing', action='store_true',
                        help='Prints a list of shards that are not synced. The format is: <shard>:<bdb> ...')
    parser.add_argument('--check-versions-match', nargs="+",
                        help='Check that all shards are running a supported redis version')
    parser.add_argument('--check-cluster-enables-changes', action='store_true',
                        help='Check that the cluster currently enables changes')

    args = parser.parse_args()

    pre_upgrade_checker = PreUpgradeChecker()
    if args.upgrade_attempt:
        pre_upgrade_checker.upgrade_attempt()
    if args.quorum:
        pre_upgrade_checker.quorum_checks()
    if args.check_legacy_databases:
        pre_upgrade_checker.check_legacy_databases()
    if args.check_master_version and args.node_uid:
        pre_upgrade_checker.check_master_version(args.node_uid)
    if args.node_new_version:
        pre_upgrade_checker.check_cluster_nodes_versions(args.node_new_version)
    if args.check_certs_match:
        pre_upgrade_checker.check_certificates_in_ccs_and_disk_match(args.check_certs_match)
    if args.check_sm_availability:
        pre_upgrade_checker.check_sm_availability()
    if args.check_versions_match:
        pre_upgrade_checker.check_versions_match(args.check_versions_match)
    if args.shards_syncing:
        print(pre_upgrade_checker.shards_syncing())
    if args.check_cluster_enables_changes:
        pre_upgrade_checker.check_cluster_enables_changes()
