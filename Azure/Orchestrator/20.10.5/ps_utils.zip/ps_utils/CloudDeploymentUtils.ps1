function SendLogToInsights ($insightsKey, $logFile) {
    $TelClient = New-Object "Microsoft.ApplicationInsights.TelemetryClient"
    $TelClient.InstrumentationKey = $insightsKey
    
    foreach ($row in Get-Content $logFile) {
        $TelClient.TrackEvent("[PSConfig] $row")
    }
    $TelClient.Flush()
}